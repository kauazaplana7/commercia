const $=s=>document.querySelector(s), money=n=>Number(n||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'}), today=()=>new Date().toLocaleDateString('pt-BR');
let data=JSON.parse(localStorage.getItem('commercia_data')||'{"products":[],"sales":[],"employees":[]}'), user='Administrador', modalAction=null;
const save=()=>{localStorage.setItem('commercia_data',JSON.stringify(data));render()}, toast=m=>{let t=$('#toast');t.textContent=m;t.classList.remove('hidden');setTimeout(()=>t.classList.add('hidden'),2600)};
function enter(){user=$('#loginName').value.trim()||'Administrador';if($('#loginPass').value!=='1234'){toast('Senha de demonstração: 1234');return}$('#login').classList.add('hidden');$('#app').classList.remove('hidden');$('#userLabel').textContent=user;$('#helloName').textContent=user;$('#dateLabel').textContent=new Date().toLocaleDateString('pt-BR',{weekday:'long',day:'2-digit',month:'long',year:'numeric'});render()}
$('#loginBtn').onclick=enter;$('#loginPass').addEventListener('keydown',e=>{if(e.key==='Enter')enter()});$('#logout').onclick=()=>{ $('#app').classList.add('hidden');$('#login').classList.remove('hidden')};
function go(page){document.querySelectorAll('.page').forEach(x=>x.classList.add('hidden'));$('#page-'+page).classList.remove('hidden');document.querySelectorAll('.nav').forEach(x=>x.classList.toggle('active',x.dataset.page===page));$('#title').textContent=({home:'Visão geral',sales:'Vendas',products:'Produtos e estoque',employees:'Funcionários',reports:'Relatórios'})[page];render()}
document.querySelectorAll('.nav').forEach(b=>b.onclick=()=>go(b.dataset.page));document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>go(b.dataset.go));
function table(headers,rows){if(!rows.length)return '<div class="empty">Ainda não há registros por aqui.</div>';return '<table><thead><tr>'+headers.map(h=>'<th>'+h+'</th>').join('')+'</tr></thead><tbody>'+rows.join('')+'</tbody></table>'}
function render(){let revenue=data.sales.reduce((s,x)=>s+x.total,0),low=data.products.filter(p=>p.qty<=5);$('#totalSales').textContent=data.sales.length;$('#revenue').textContent=money(revenue);$('#totalProducts').textContent=data.products.length;$('#lowStock').textContent=low.length;$('#recentSales').innerHTML=table(['DATA','CLIENTE','TOTAL'],data.sales.slice(-5).reverse().map(s=>`<tr><td>${s.date}</td><td>${esc(s.client)}</td><td><b>${money(s.total)}</b></td></tr>`));$('#stockAlerts').innerHTML=low.length?low.slice(0,6).map(p=>`<div class="stock-row"><span>${esc(p.name)}</span><span class="tag">${p.qty} un.</span></div>`).join(''):'<div class="empty">Estoque em dia. Nenhum alerta.</div>';$('#salesTable').innerHTML=table(['DATA','CLIENTE','ITENS','TOTAL'],data.sales.slice().reverse().map(s=>`<tr><td>${s.date}</td><td>${esc(s.client)}</td><td>${s.items}</td><td><b>${money(s.total)}</b></td></tr>`));let q=($('#productSearch')?.value||'').toLowerCase();let ps=data.products.filter(p=>p.name.toLowerCase().includes(q));$('#productsTable').innerHTML=table(['PRODUTO','CATEGORIA','PREÇO','ESTOQUE','AÇÕES'],ps.map(p=>`<tr><td><b>${esc(p.name)}</b></td><td>${esc(p.category||'—')}</td><td>${money(p.price)}</td><td>${p.qty} ${p.qty<=5?'<span class="tag">Baixo</span>':''}</td><td><button class="text-btn" onclick="editProduct('${p.id}')">Editar</button> <button class="text-btn" onclick="del('products','${p.id}')">Excluir</button></td></tr>`));$('#productCount').textContent=data.products.length+' produtos';$('#employeesTable').innerHTML=table(['NOME','FUNÇÃO','CONTATO','AÇÕES'],data.employees.map(e=>`<tr><td><b>${esc(e.name)}</b></td><td>${esc(e.role||'—')}</td><td>${esc(e.contact||'—')}</td><td><button class="text-btn" onclick="del('employees','${e.id}')">Excluir</button></td></tr>`));$('#reportRevenue').textContent=money(revenue);$('#avgTicket').textContent=money(data.sales.length?revenue/data.sales.length:0);$('#stockValue').textContent=money(data.products.reduce((s,p)=>s+p.price*p.qty,0));$('#reportSummary').innerHTML=`<div>Produtos cadastrados<b>${data.products.length}</b></div><div>Funcionários cadastrados<b>${data.employees.length}</b></div><div>Vendas registradas<b>${data.sales.length}</b></div><div>Itens em estoque baixo<b>${low.length}</b></div>`}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function openModal(title,fields,action){$('#modalTitle').textContent=title;$('#modalFields').innerHTML='<div class="field-grid">'+fields.map(f=>`<div class="${f.full?'full-field':''}"><label>${f.label}</label><input name="${f.name}" type="${f.type||'text'}" ${f.required?'required':''} ${f.step?'step="'+f.step+'"':''} value="${esc(f.value??'')}"></div>`).join('')+'</div>';modalAction=action;$('#modal').classList.remove('hidden')}
function close(){ $('#modal').classList.add('hidden') }$('#closeModal').onclick=$('#cancelModal').onclick=close;
$('#addProduct').onclick=()=>openModal('Novo produto',[{label:'Nome do produto',name:'name',required:true,full:true},{label:'Categoria',name:'category'},{label:'Preço de venda (R$)',name:'price',type:'number',step:'0.01',required:true},{label:'Quantidade em estoque',name:'qty',type:'number',required:true}],v=>{data.products.push({id:crypto.randomUUID(),name:v.name,category:v.category,price:+v.price,qty:+v.qty});save();toast('Produto cadastrado!')});
window.editProduct=id=>{let p=data.products.find(x=>x.id===id);openModal('Editar produto',[{label:'Nome',name:'name',value:p.name,required:true,full:true},{label:'Categoria',name:'category',value:p.category},{label:'Preço (R$)',name:'price',type:'number',step:'0.01',value:p.price,required:true},{label:'Estoque',name:'qty',type:'number',value:p.qty,required:true}],v=>{Object.assign(p,{name:v.name,category:v.category,price:+v.price,qty:+v.qty});save();toast('Produto atualizado!')})};
$('#addEmployee').onclick=()=>openModal('Adicionar funcionário',[{label:'Nome completo',name:'name',required:true,full:true},{label:'Função',name:'role'},{label:'Contato',name:'contact'}],v=>{data.employees.push({id:crypto.randomUUID(),...v});save();toast('Funcionário cadastrado!')});
function newSale(){if(!data.products.length){toast('Cadastre um produto antes de registrar uma venda.');go('products');return}openModal('Registrar venda',[{label:'Nome do cliente',name:'client',value:'Cliente balcão',full:true},{label:'Produto',name:'product',type:'text',required:true,full:true},{label:'Quantidade',name:'qty',type:'number',value:1,required:true}],v=>{let p=data.products.find(x=>x.name.toLowerCase()===v.product.toLowerCase());if(!p){toast('Produto não encontrado. Digite o nome igual ao cadastro.');return}let qty=+v.qty;if(qty<1||qty>p.qty){toast('Quantidade indisponível no estoque.');return}p.qty-=qty;data.sales.push({id:crypto.randomUUID(),date:today(),client:v.client,items:qty,total:p.price*qty});save();toast('Venda registrada e estoque atualizado!')})}
$('#newSale').onclick=$('#newSaleTop').onclick=newSale;
window.del=(key,id)=>{if(confirm('Deseja realmente excluir este registro?')){data[key]=data[key].filter(x=>x.id!==id);save();toast('Registro excluído.')}};
$('#productSearch').addEventListener('input',render);
$('#modalForm').onsubmit=e=>{e.preventDefault();let v=Object.fromEntries(new FormData(e.target));let ok=modalAction?.(v);if(ok!==false)close()};
$('#exportData').onclick=()=>{let blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='commercia-backup.json';a.click();URL.revokeObjectURL(a.href);toast('Backup exportado!')};
$('#clearData').onclick=()=>{if(confirm('Isso apagará produtos, vendas e funcionários deste navegador. Continuar?')){data={products:[],sales:[],employees:[]};save();toast('Dados locais apagados.')}};
render();

// Preferências de acessibilidade
const accessibilityDefaults={largeText:false,highContrast:false,reduceMotion:window.matchMedia?.('(prefers-reduced-motion: reduce)').matches||false};
let accessibilityPrefs={...accessibilityDefaults,...JSON.parse(localStorage.getItem('commercia_accessibility')||'{}')};
function applyAccessibility(){
  document.body.classList.toggle('large-text',!!accessibilityPrefs.largeText);
  document.body.classList.toggle('high-contrast',!!accessibilityPrefs.highContrast);
  document.body.classList.toggle('reduce-motion',!!accessibilityPrefs.reduceMotion);
  $('#contrastToggle').checked=!!accessibilityPrefs.highContrast;
  $('#motionToggle').checked=!!accessibilityPrefs.reduceMotion;
  localStorage.setItem('commercia_accessibility',JSON.stringify(accessibilityPrefs));
}
function setAccessibility(key,value){accessibilityPrefs[key]=value;applyAccessibility()}
$('#accessibilityOpen').onclick=()=>{$('#accessibilityPanel').classList.remove('hidden');$('#accessibilityTitle').setAttribute('tabindex','-1');$('#accessibilityTitle').focus()};
function closeAccessibility(){$('#accessibilityPanel').classList.add('hidden');$('#accessibilityOpen').focus()}
$('#accessibilityClose').onclick=closeAccessibility;
$('#fontIncrease').onclick=()=>setAccessibility('largeText',true);
$('#fontDecrease').onclick=()=>setAccessibility('largeText',false);
$('#fontReset').onclick=()=>setAccessibility('largeText',false);
$('#contrastToggle').onchange=e=>setAccessibility('highContrast',e.target.checked);
$('#motionToggle').onchange=e=>setAccessibility('reduceMotion',e.target.checked);
$('#accessibilityReset').onclick=()=>{accessibilityPrefs={...accessibilityDefaults};applyAccessibility()};
$('#accessibilityPanel').addEventListener('keydown',e=>{if(e.key==='Escape')closeAccessibility()});
applyAccessibility();

// Mantém o foco no conteúdo principal após trocar de seção.
const originalGo=go;
go=function(page){originalGo(page);$('#page-'+page).setAttribute('tabindex','-1');$('#page-'+page).focus({preventScroll:true})};

// Restaura o foco ao fechar formulários e informa campos gerados aos leitores de tela.
const originalOpenModal=openModal;
openModal=function(title,fields,action){
  originalOpenModal(title,fields,action);
  const inputs=$('#modalFields').querySelectorAll('input');
  inputs.forEach((input,i)=>{
    const label=input.parentElement.querySelector('label');
    if(label){const id='modal-field-'+i;input.id=id;label.htmlFor=id}
  });
  $('#modalTitle').setAttribute('tabindex','-1');$('#modalTitle').focus();
};
